#!/bin/bash

mysql -uroot -p
