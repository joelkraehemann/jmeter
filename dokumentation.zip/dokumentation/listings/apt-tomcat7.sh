#!/bin/bash

apt-get -t testing install tomcat7
