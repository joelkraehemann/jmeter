#!/bin/bash

mysql -uopenolat -popenolat openolat < ~/openolat/src/main/resources/database/mysql/setupDatabase.sql
