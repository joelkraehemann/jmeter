#!/bin/bash

cd
hg clone http://hg.openolat.org/openolat openolat
