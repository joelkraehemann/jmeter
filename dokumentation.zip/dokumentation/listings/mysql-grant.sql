grant all privileges on openolat.* to openolat@localhost identified by 'openolat';
create database openolat CHARSET 'utf8';
