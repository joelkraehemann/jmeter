#!/bin/bash

apt-get -t testing install java7-jdk mysql-server mysql-client tomcat7 maven2
