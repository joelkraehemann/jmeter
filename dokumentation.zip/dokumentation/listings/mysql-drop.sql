drop database if exists openolat;
