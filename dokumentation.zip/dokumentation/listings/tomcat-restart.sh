#!/bin/bash

/etc/init.d/tomcat7 restart
